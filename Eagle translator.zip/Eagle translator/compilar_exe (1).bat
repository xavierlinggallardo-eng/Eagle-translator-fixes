@echo off
cd /d "C:\Users\Administrator\Downloads\RenpyTranslator te pre last fixx\RenpyTranslator te pre last fix\RenpyTranslator"

pip install pyinstaller --quiet

pyinstaller --onefile --windowed --icon="Eagler.ico" --name="Eagle Translator" --add-data="Eagler.ico;." main.py

echo.
echo Listo! El exe esta en dist\
pause
